-- MySQL dump 10.13  Distrib 5.7.28, for Linux (x86_64)
--
-- Host: ccsddb04    Database: HALV3
-- ------------------------------------------------------
-- Server version	5.6.46-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `SITE`
--
-- WHERE:  SID=1

LOCK TABLES `SITE` WRITE;
/*!40000 ALTER TABLE `SITE` DISABLE KEYS */;
INSERT INTO `SITE` VALUES (1,'PORTAIL','hal','hal-','https://hal.archives-ouvertes.fr','Archive ouverte HAL','GEN','2002-03-01','hal@ccsd.cnrs.fr',4778213);
/*!40000 ALTER TABLE `SITE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `PORTAIL_DOMAIN`
--
-- WHERE:  SID=1

LOCK TABLES `PORTAIL_DOMAIN` WRITE;
/*!40000 ALTER TABLE `PORTAIL_DOMAIN` DISABLE KEYS */;
INSERT INTO `PORTAIL_DOMAIN` VALUES (1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(1,7),(1,8),(1,9),(1,10),(1,11),(1,12),(1,13),(1,14),(1,15),(1,16),(1,17),(1,18),(1,19),(1,20),(1,21),(1,22),(1,23),(1,24),(1,25),(1,26),(1,27),(1,28),(1,29),(1,30),(1,31),(1,32),(1,33),(1,34),(1,35),(1,36),(1,37),(1,38),(1,39),(1,40),(1,41),(1,42),(1,43),(1,44),(1,45),(1,46),(1,47),(1,48),(1,49),(1,50),(1,51),(1,52),(1,53),(1,54),(1,55),(1,56),(1,57),(1,58),(1,59),(1,60),(1,61),(1,62),(1,63),(1,64),(1,65),(1,66),(1,67),(1,68),(1,69),(1,70),(1,71),(1,72),(1,73),(1,74),(1,75),(1,76),(1,77),(1,78),(1,79),(1,80),(1,81),(1,82),(1,83),(1,84),(1,85),(1,86),(1,87),(1,88),(1,89),(1,90),(1,91),(1,92),(1,93),(1,94),(1,95),(1,96),(1,97),(1,98),(1,99),(1,100),(1,101),(1,102),(1,103),(1,104),(1,105),(1,106),(1,107),(1,108),(1,109),(1,110),(1,111),(1,112),(1,113),(1,114),(1,115),(1,116),(1,117),(1,118),(1,119),(1,120),(1,121),(1,122),(1,123),(1,124),(1,125),(1,126),(1,127),(1,128),(1,129),(1,130),(1,131),(1,132),(1,133),(1,134),(1,135),(1,136),(1,137),(1,138),(1,139),(1,140),(1,141),(1,142),(1,143),(1,144),(1,145),(1,146),(1,147),(1,148),(1,149),(1,150),(1,151),(1,152),(1,153),(1,154),(1,155),(1,156),(1,157),(1,158),(1,159),(1,160),(1,161),(1,162),(1,163),(1,164),(1,165),(1,166),(1,167),(1,168),(1,169),(1,170),(1,171),(1,172),(1,173),(1,174),(1,175),(1,176),(1,177),(1,178),(1,179),(1,180),(1,181),(1,182),(1,183),(1,184),(1,185),(1,186),(1,187),(1,188),(1,189),(1,190),(1,191),(1,192),(1,193),(1,194),(1,195),(1,196),(1,197),(1,198),(1,199),(1,200),(1,201),(1,202),(1,203),(1,204),(1,205),(1,206),(1,207),(1,208),(1,209),(1,210),(1,211),(1,212),(1,213),(1,214),(1,215),(1,216),(1,217),(1,218),(1,219),(1,220),(1,221),(1,222),(1,223),(1,224),(1,225),(1,226),(1,227),(1,228),(1,229),(1,230),(1,231),(1,232),(1,233),(1,234),(1,235),(1,236),(1,237),(1,238),(1,239),(1,240),(1,241),(1,242),(1,243),(1,244),(1,245),(1,246),(1,247),(1,248),(1,249),(1,250),(1,251),(1,252),(1,253),(1,254),(1,255),(1,256),(1,257),(1,258),(1,259),(1,260),(1,261),(1,262),(1,263),(1,264),(1,265),(1,266),(1,267),(1,268),(1,269),(1,270),(1,271),(1,272),(1,273),(1,274),(1,275),(1,276),(1,277),(1,278),(1,279),(1,280),(1,281),(1,282),(1,283),(1,284),(1,285),(1,286),(1,287),(1,288),(1,289),(1,290),(1,291),(1,292),(1,293),(1,294),(1,295),(1,296),(1,297),(1,298),(1,299),(1,300),(1,301),(1,302),(1,303),(1,304),(1,305),(1,306),(1,307),(1,308),(1,309),(1,310),(1,311),(1,312),(1,313),(1,314),(1,315),(1,316),(1,317),(1,318),(1,319),(1,320),(1,321),(1,322),(1,323),(1,324),(1,325),(1,326),(1,327),(1,328),(1,329),(1,330),(1,331),(1,332),(1,333),(1,334),(1,335),(1,336),(1,337),(1,338),(1,339),(1,340),(1,341),(1,342),(1,343),(1,344),(1,345),(1,346),(1,347),(1,348),(1,349),(1,350),(1,351),(1,352),(1,353),(1,354),(1,355),(1,356),(1,357),(1,358),(1,359),(1,360),(1,361),(1,362),(1,363),(1,364),(1,365),(1,366),(1,367),(1,368),(1,369),(1,370),(1,371),(1,372),(1,373),(1,374),(1,375),(1,376),(1,377),(1,378),(1,379),(1,380),(1,381),(1,382),(1,383),(1,384),(1,385),(1,386),(1,387),(1,388),(1,389),(1,390),(1,391),(1,392),(1,393);
/*!40000 ALTER TABLE `PORTAIL_DOMAIN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `PORTAIL_SETTINGS`
--
-- WHERE:  SID=1

LOCK TABLES `PORTAIL_SETTINGS` WRITE;
/*!40000 ALTER TABLE `PORTAIL_SETTINGS` DISABLE KEYS */;
INSERT INTO `PORTAIL_SETTINGS` VALUES (1,'MAIN_TYPDOC','ART, COMM, COUV, OTHER, OUV, DOUV, UNDEFINED, REPORT, THESE, HDR, LECTURE'),(1,'TYPDOC','a:4:{s:8:\"typdoc_1\";a:4:{s:2:\"id\";s:8:\"typdoc_1\";s:4:\"type\";s:8:\"category\";s:5:\"label\";s:15:\"typdoc_typdoc_1\";s:8:\"children\";a:8:{s:3:\"ART\";a:3:{s:2:\"id\";s:3:\"ART\";s:4:\"type\";s:6:\"typdoc\";s:5:\"label\";s:10:\"typdoc_ART\";}s:4:\"COMM\";a:3:{s:2:\"id\";s:4:\"COMM\";s:4:\"type\";s:6:\"typdoc\";s:5:\"label\";s:11:\"typdoc_COMM\";}s:6:\"POSTER\";a:3:{s:2:\"id\";s:6:\"POSTER\";s:4:\"type\";s:6:\"typdoc\";s:5:\"label\";s:13:\"typdoc_POSTER\";}s:3:\"OUV\";a:3:{s:2:\"id\";s:3:\"OUV\";s:4:\"type\";s:6:\"typdoc\";s:5:\"label\";s:10:\"typdoc_OUV\";}s:4:\"COUV\";a:3:{s:2:\"id\";s:4:\"COUV\";s:4:\"type\";s:6:\"typdoc\";s:5:\"label\";s:11:\"typdoc_COUV\";}s:4:\"DOUV\";a:3:{s:2:\"id\";s:4:\"DOUV\";s:4:\"type\";s:6:\"typdoc\";s:5:\"label\";s:11:\"typdoc_DOUV\";}s:6:\"PATENT\";a:3:{s:2:\"id\";s:6:\"PATENT\";s:4:\"type\";s:6:\"typdoc\";s:5:\"label\";s:13:\"typdoc_PATENT\";}s:5:\"OTHER\";a:3:{s:2:\"id\";s:5:\"OTHER\";s:4:\"type\";s:6:\"typdoc\";s:5:\"label\";s:12:\"typdoc_OTHER\";}}}s:8:\"typdoc_2\";a:4:{s:2:\"id\";s:8:\"typdoc_2\";s:4:\"type\";s:8:\"category\";s:5:\"label\";s:15:\"typdoc_typdoc_2\";s:8:\"children\";a:2:{s:9:\"UNDEFINED\";a:3:{s:2:\"id\";s:9:\"UNDEFINED\";s:4:\"type\";s:6:\"typdoc\";s:5:\"label\";s:16:\"typdoc_UNDEFINED\";}s:6:\"REPORT\";a:3:{s:2:\"id\";s:6:\"REPORT\";s:4:\"type\";s:6:\"typdoc\";s:5:\"label\";s:13:\"typdoc_REPORT\";}}}s:8:\"typdoc_3\";a:4:{s:2:\"id\";s:8:\"typdoc_3\";s:4:\"type\";s:8:\"category\";s:5:\"label\";s:15:\"typdoc_typdoc_3\";s:8:\"children\";a:3:{s:5:\"THESE\";a:3:{s:2:\"id\";s:5:\"THESE\";s:4:\"type\";s:6:\"typdoc\";s:5:\"label\";s:12:\"typdoc_THESE\";}s:3:\"HDR\";a:3:{s:2:\"id\";s:3:\"HDR\";s:4:\"type\";s:6:\"typdoc\";s:5:\"label\";s:10:\"typdoc_HDR\";}s:7:\"LECTURE\";a:3:{s:2:\"id\";s:7:\"LECTURE\";s:4:\"type\";s:6:\"typdoc\";s:5:\"label\";s:14:\"typdoc_LECTURE\";}}}s:8:\"typdoc_4\";a:4:{s:2:\"id\";s:8:\"typdoc_4\";s:4:\"type\";s:8:\"category\";s:5:\"label\";s:15:\"typdoc_typdoc_4\";s:8:\"children\";a:4:{s:3:\"IMG\";a:3:{s:2:\"id\";s:3:\"IMG\";s:4:\"type\";s:6:\"typdoc\";s:5:\"label\";s:10:\"typdoc_IMG\";}s:5:\"VIDEO\";a:3:{s:2:\"id\";s:5:\"VIDEO\";s:4:\"type\";s:6:\"typdoc\";s:5:\"label\";s:12:\"typdoc_VIDEO\";}s:3:\"SON\";a:3:{s:2:\"id\";s:3:\"SON\";s:4:\"type\";s:6:\"typdoc\";s:5:\"label\";s:10:\"typdoc_SON\";}s:3:\"MAP\";a:3:{s:2:\"id\";s:3:\"MAP\";s:4:\"type\";s:6:\"typdoc\";s:5:\"label\";s:10:\"typdoc_MAP\";}}}}');
/*!40000 ALTER TABLE `PORTAIL_SETTINGS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `WEBSITE`
--
-- WHERE:  SID=1

LOCK TABLES `WEBSITE` WRITE;
/*!40000 ALTER TABLE `WEBSITE` DISABLE KEYS */;
/*!40000 ALTER TABLE `WEBSITE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `WEBSITE_FOOTER`
--
-- WHERE:  SID=1

LOCK TABLES `WEBSITE_FOOTER` WRITE;
/*!40000 ALTER TABLE `WEBSITE_FOOTER` DISABLE KEYS */;
/*!40000 ALTER TABLE `WEBSITE_FOOTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `WEBSITE_HEADER`
--
-- WHERE:  SID=1

LOCK TABLES `WEBSITE_HEADER` WRITE;
/*!40000 ALTER TABLE `WEBSITE_HEADER` DISABLE KEYS */;
INSERT INTO `WEBSITE_HEADER` VALUES (33005,1,'img','hal.logo.png','','','','hal','a:0:{}','','','left');
/*!40000 ALTER TABLE `WEBSITE_HEADER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `WEBSITE_NAVIGATION`
--
-- WHERE:  SID=1

LOCK TABLES `WEBSITE_NAVIGATION` WRITE;
/*!40000 ALTER TABLE `WEBSITE_NAVIGATION` DISABLE KEYS */;
INSERT INTO `WEBSITE_NAVIGATION` VALUES (674606,1,10,'Hal_Website_Navigation_Page_Search','search','index','menu-label-10',0,''),(674607,1,11,'Hal_Website_Navigation_Page_Link','','https://doc.archives-ouvertes.fr','menu-label-11',0,'a:2:{s:4:\"link\";s:32:\"https://doc.archives-ouvertes.fr\";s:6:\"target\";s:6:\"_blank\";}'),(674604,1,8,'Hal_Website_Navigation_Page_Portails','browse','portal','menu-label-8',2,''),(674605,1,9,'Hal_Website_Navigation_Page_Collections','browse','collection','menu-label-9',2,'a:2:{s:5:\"field\";s:24:\"collection_with_category\";s:4:\"sort\";s:5:\"index\";}'),(674603,1,7,'Hal_Website_Navigation_Page_Structure','browse','structure','menu-label-7',2,'a:1:{s:5:\"field\";s:9:\"structure\";}'),(674602,1,6,'Hal_Website_Navigation_Page_Period','browse','period','menu-label-6',2,'a:9:{s:10:\"facetRange\";s:15:\"producedDateY_i\";s:15:\"facetRangeStart\";s:4:\"1975\";s:13:\"facetRangeEnd\";s:0:\"\";s:13:\"facetRangeGap\";s:1:\"5\";s:17:\"facetRangeHardend\";s:4:\"true\";s:17:\"facetRangeInclude\";s:3:\"all\";s:15:\"facetRangeOther\";s:3:\"all\";s:12:\"rangeSorting\";s:4:\"desc\";s:6:\"filter\";a:0:{}}'),(674601,1,5,'Hal_Website_Navigation_Page_Domain','browse','domain','menu-label-5',2,'a:1:{s:11:\"displayType\";s:6:\"portal\";}'),(674600,1,4,'Hal_Website_Navigation_Page_Doctype','browse','doctype','menu-label-4',2,''),(674596,1,0,'Hal_Website_Navigation_Page_Index','index','index','menu-label-0',0,''),(674597,1,1,'Hal_Website_Navigation_Page_Submit','submit','index','menu-label-1',0,''),(674598,1,2,'Hal_Website_Navigation_Page_Folder','section','list2','menu-label-2',0,''),(674599,1,3,'Hal_Website_Navigation_Page_Last','browse','last','menu-label-3',2,'');
/*!40000 ALTER TABLE `WEBSITE_NAVIGATION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `WEBSITE_SETTINGS`
--
-- WHERE:  SID=1

LOCK TABLES `WEBSITE_SETTINGS` WRITE;
/*!40000 ALTER TABLE `WEBSITE_SETTINGS` DISABLE KEYS */;
INSERT INTO `WEBSITE_SETTINGS` VALUES (1,'languages','a:2:{i:0;s:2:\"fr\";i:1;s:2:\"en\";}'),(1,'PIWIKID','17');
/*!40000 ALTER TABLE `WEBSITE_SETTINGS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `WEBSITE_STYLES`
--
-- WHERE:  SID=1

LOCK TABLES `WEBSITE_STYLES` WRITE;
/*!40000 ALTER TABLE `WEBSITE_STYLES` DISABLE KEYS */;
INSERT INTO `WEBSITE_STYLES` VALUES (1,'template','tpl1'),(1,'bg_img','1'),(1,'font_size','10'),(1,'title_font_family','Verdana, Geneva, sans-serif'),(1,'title_size','10'),(1,'bg_img_repeat','repeat'),(1,'bg_img_pos_v','top'),(1,'bg_img_pos_h','left'),(1,'navigation','tabs'),(1,'container_width','container'),(1,'type','css'),(1,'font_family','Verdana, Geneva, sans-serif'),(1,'breadcrumbs','yes');
/*!40000 ALTER TABLE `WEBSITE_STYLES` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-19 15:48:17
